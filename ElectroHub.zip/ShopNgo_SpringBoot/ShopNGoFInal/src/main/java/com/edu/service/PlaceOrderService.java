package com.edu.service;

import java.util.List;

import com.edu.dao.PlaceOrder;
import com.edu.error.GlobalException;

public interface PlaceOrderService {

	public void savePlaceOrder(PlaceOrder placeorder, String phonenuumber, Integer produtid) throws GlobalException;

	public PlaceOrder getPlaceOrder();

	public List<PlaceOrder> getAllPlaceOrder();

	public String updatePaymentStatus();

}
