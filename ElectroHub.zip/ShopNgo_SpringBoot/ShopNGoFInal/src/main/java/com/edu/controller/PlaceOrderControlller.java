package com.edu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.edu.dao.PlaceOrder;
import com.edu.error.GlobalException;
import com.edu.service.PlaceOrderService;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class PlaceOrderControlller {
	
	@Autowired
    private PlaceOrderService placeorderservice;
	
	
	@PostMapping("/savePlaceOrder/{phonenumber}/{produtid}")
	void savePlaceOrder(@RequestBody PlaceOrder placeorder,@PathVariable String  phonenumber,@PathVariable Integer produtid ) throws GlobalException {
		placeorderservice.savePlaceOrder( placeorder,phonenumber,produtid );
		
	}
	
	@GetMapping("/getPlaceOrder")
	PlaceOrder getPlaceOrder() {
	return placeorderservice.getPlaceOrder();
		
	}
	@GetMapping("/getAllPlaceOrder")
	List<PlaceOrder> getAllPlaceOrder() {
		return placeorderservice.getAllPlaceOrder();
		
	}
	@PutMapping("/updatePaymentStatus")
	String updatePaymentStatus() {
		return placeorderservice.updatePaymentStatus() ;
		
	}
	

}