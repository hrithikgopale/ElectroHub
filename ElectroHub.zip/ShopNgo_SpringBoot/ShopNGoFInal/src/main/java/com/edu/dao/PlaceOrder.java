package com.edu.dao;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class PlaceOrder {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer placeorderid;
	
 private String placeordercustomername;
 
 private String placeordercustmeraddress;
 
 private String placeordercustomerphonenumber;
 
 private Integer placeorderquantity;
 
 private double placeordertotalamount;

private String placeorderloginphonenumber;

private Integer placeorderproductid;

private Integer placeorderactualprice;

private String placeorderproductname;

private String placeorderpaymentStatus;

private String placeorderdeliverystatus;



 
public PlaceOrder() {
	super();
	// TODO Auto-generated constructor stub
}
//
//public PlaceOrder(String placeordercustomername, String placeordercustmeraddress, String placeordercustomerphonenumber,
//		Integer placeorderquantity, double placeordertotalamount, String placeorderloginphonenumber,
//		Integer placeorderproductid) {
//	super();
//	this.placeordercustomername = placeordercustomername;
//	this.placeordercustmeraddress = placeordercustmeraddress;
//	this.placeordercustomerphonenumber = placeordercustomerphonenumber;
//	this.placeorderquantity = placeorderquantity;
//	this.placeordertotalamount = placeordertotalamount;
//	this.placeorderloginphonenumber = placeorderloginphonenumber;
//	this.placeorderproductid = placeorderproductid;
//}











public String getPlaceorderdeliverystatus() {
	return placeorderdeliverystatus;
}





public String getPlaceorderpaymentStatus() {
	return placeorderpaymentStatus;
}























public void setPlaceorderdeliverystatus(String placeorderdeliverystatus) {
	this.placeorderdeliverystatus = placeorderdeliverystatus;
}





public Integer getPlaceorderid() {
	return placeorderid;
}

public PlaceOrder(String placeordercustomername, String placeordercustmeraddress, String placeordercustomerphonenumber,
		Integer placeorderquantity, double placeordertotalamount, String placeorderloginphonenumber,
		Integer placeorderproductid, Integer placeorderactualprice, String placeorderproductname) {
	super();
	this.placeordercustomername = placeordercustomername;
	this.placeordercustmeraddress = placeordercustmeraddress;
	this.placeordercustomerphonenumber = placeordercustomerphonenumber;
	this.placeorderquantity = placeorderquantity;
	this.placeordertotalamount = placeordertotalamount;
	this.placeorderloginphonenumber = placeorderloginphonenumber;
	this.placeorderproductid = placeorderproductid;
	this.placeorderactualprice = placeorderactualprice;
	this.placeorderproductname = placeorderproductname;
}


public Integer getPlaceorderactualprice() {
	return placeorderactualprice;
}







public String getPlaceorderproductname() {
	return placeorderproductname;
}





public void setPlaceorderproductname(String placeorderproductname) {
	this.placeorderproductname = placeorderproductname;
}





public void setPlaceorderid(Integer placeorderid) {
	this.placeorderid = placeorderid;
}

public String getPlaceordercustomername() {
	return placeordercustomername;
}

public void setPlaceordercustomername(String placeordercustomername) {
	this.placeordercustomername = placeordercustomername;
}

public String getPlaceordercustmeraddress() {
	return placeordercustmeraddress;
}

public void setPlaceordercustmeraddress(String placeordercustmeraddress) {
	this.placeordercustmeraddress = placeordercustmeraddress;
}

public String getPlaceordercustomerphonenumber() {
	return placeordercustomerphonenumber;
}

public void setPlaceordercustomerphonenumber(String placeordercustomerphonenumber) {
	this.placeordercustomerphonenumber = placeordercustomerphonenumber;
}

public Integer getPlaceorderquantity() {
	return placeorderquantity;
}

public void setPlaceorderquantity(Integer placeorderquantity) {
	this.placeorderquantity = placeorderquantity;
}

public double getPlaceordertotalamount() {
	return placeordertotalamount;
}

public void setPlaceordertotalamount(double placeordertotalamount) {
	this.placeordertotalamount = placeordertotalamount;
}

public String getPlaceorderloginphonenumber() {
	return placeorderloginphonenumber;
}

//public void setPlaceorderloginphonenumber(String placeorderloginphonenumber) {
//	this.placeorderloginphonenumber = placeorderloginphonenumber;
//}

public Integer getPlaceorderproductid() {
	return placeorderproductid;
}

public void setPlaceorderproductid(Integer placeorderproductid) {
	this.placeorderproductid = placeorderproductid;
}

@Override
public String toString() {
	return "PlaceOrder [placeorderid=" + placeorderid + ", placeordercustomername=" + placeordercustomername
			+ ", placeordercustmeraddress=" + placeordercustmeraddress + ", placeordercustomerphonenumber="
			+ placeordercustomerphonenumber + ", placeorderquantity=" + placeorderquantity + ", placeordertotalamount="
			+ placeordertotalamount + ", placeorderloginphonenumber=" + placeorderloginphonenumber
			+ ", placeorderproductid=" + placeorderproductid + "]";
}

public void setPlaceorderloginphonenumber(String placeorderloginphonenumber) {
	// TODO Auto-generated method stub
	this.placeorderloginphonenumber = placeorderloginphonenumber;
	}





public void setPlaceorderactualprice(Integer placeorderactualprice) {
	
	this.placeorderactualprice = placeorderactualprice;
}











public void setPlaceorderpaymentStatus(String placeorderpaymentStatus2) {
	// TODO Auto-generated method stub
	this.placeorderpaymentStatus = placeorderpaymentStatus2;
}






	
}