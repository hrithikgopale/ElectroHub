package com.edu.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.dao.CardDetails;
import com.edu.repository.CardDetailsRepository;

@Service
public class CardDetailsServiceImpl implements CardDetailsService  {
	
	@Autowired
	private  CardDetailsRepository cardDetailsRepository;
	
	@Autowired
	private PlaceOrderServiceImpl placeOrderService;

	@Override
	public CardDetails savecarddetails(CardDetails cardDetails) {
		// TODO Auto-generated method stub
		return cardDetailsRepository.save(cardDetails);
	}
//	@Override
//    public boolean validateCardDetails(String cardNumber, String cvv) {
//        // Perform custom validation on the card details
//        // Implement your validation logic here, e.g., check if cardNumber and cvv match with any existing cart details in the database
//
//        // Retrieve the cart details based on the provided card number and cvv
//        Optional<CardDetails> optionalCardDetails = cardDetailsRepository.findByCardNumberAndCvv(cardNumber, cvv);
//
//        // Return true if the card details exist in the database, false otherwise
//        return optionalCardDetails.isPresent();
//    }

	@Override
    public boolean validateCardDetails(String cardNumber, String cardHolderName, String expiryDate, String cvv) {
        // Fetch card details from the database based on the card number
        Optional<CardDetails> cardDetailsOptional = cardDetailsRepository.findByCardNumber(cardNumber);

        // Check if card details exist in the database
        if (cardDetailsOptional.isPresent()) {
            CardDetails cardDetails = cardDetailsOptional.get();

            // Validate card details against the provided information
            if (cardDetails.getCardHolderName().equals(cardHolderName)
                    && cardDetails.getExpiryDate().equals(expiryDate)
                    && cardDetails.getCvv().equals(cvv)) {
            	placeOrderService.updatePaymentStatus();
                return true; // Card details are valid
                
            }
        }

        return false; // Card details are not valid or not found
    }

	
}