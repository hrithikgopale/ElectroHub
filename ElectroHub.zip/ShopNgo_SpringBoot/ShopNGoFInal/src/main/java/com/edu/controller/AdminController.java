package com.edu.controller;

import java.util.List;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.edu.dao.Admin;
import com.edu.error.GlobalException;
import com.edu.service.AdminService;

@RestController
@RequestMapping("/api/admins")
@CrossOrigin(origins="http://localhost:4200")
public class AdminController {
@Autowired
private AdminService adminService;

@PostMapping("/saveAdmin")
ResponseEntity<Admin> saveAdmin(@Valid @RequestBody Admin admin) throws GlobalException {
Admin obj= adminService.saveAdmin(admin);
return new ResponseEntity<Admin>(obj,HttpStatus.CREATED);

}

@DeleteMapping("/deleteAdminByAdminname/adminname/{adminname}")
public String deleteAdminByAdminname(@PathVariable("adminname") String  adminname) throws GlobalException {
	adminService.deleteAdminByAdminname(adminname);
	return "admin is deleted";
	}

@GetMapping("/getAllAdmin")
List<Admin> getAllAdmin(){
	return adminService.getAllAdmin();
	
}

@PostMapping("/loginAdmin")
public boolean loginAdmin(@RequestBody Admin admin) {
	return adminService.loginAdmin(admin.getAdminname(),admin.getAdminpassword());
	
}






}