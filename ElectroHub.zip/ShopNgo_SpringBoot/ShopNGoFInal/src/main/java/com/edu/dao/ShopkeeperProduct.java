package com.edu.dao;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class ShopkeeperProduct {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer shopkeeperproductid;
	
	@Column(unique = true, nullable = false)
	private String shopkeeperproductname;
	@Column(nullable = false)
	private Long shopkeeperproductquantity;
	@Column(nullable = false)
	private Integer shopkeeperproductprice;
	
	@ManyToMany(fetch = FetchType.EAGER,cascade = CascadeType.ALL)
	@JoinTable(name="product_image",
	joinColumns = {
			@JoinColumn(name="shopkeeperproductid")
	},
	inverseJoinColumns = {
			@JoinColumn(name="image_id")
	}
			)
	private Set<ImageModel> productImages;
	
	
	


	public Set<ImageModel> getProductImages() {
		return productImages;
	}
	public void setProductImages(Set<ImageModel> productImages) {
		this.productImages = productImages;
	}
	public ShopkeeperProduct() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ShopkeeperProduct(Integer shopkeeperproductid, String shopkeeperproductname, Long shopkeeperproductquantity,
			Integer shopkeeperproductprice) {
		super();
		this.shopkeeperproductid = shopkeeperproductid;
		this.shopkeeperproductname = shopkeeperproductname;
		this.shopkeeperproductquantity = shopkeeperproductquantity;
		this.shopkeeperproductprice = shopkeeperproductprice;
	}
	
	
	public Integer getShopkeeperproductid() {
		return shopkeeperproductid;
	}
	public void setShopkeeperproductid(Integer shopkeeperproductid) {
		this.shopkeeperproductid = shopkeeperproductid;
	}
	public String getShopkeeperproductname() {
		return shopkeeperproductname;
	}
	public void setShopkeeperproductname(String shopkeeperproductname) {
		this.shopkeeperproductname = shopkeeperproductname;
	}
	public Long getShopkeeperproductquantity() {
		return shopkeeperproductquantity;
	}
	public void setShopkeeperproductquantity(Long shopkeeperproductquantity) {
		this.shopkeeperproductquantity = shopkeeperproductquantity;
	}
	public Integer getShopkeeperproductprice() {
		return shopkeeperproductprice;
	}
	public void setShopkeeperproductprice(Integer shopkeeperproductprice) {
		this.shopkeeperproductprice = shopkeeperproductprice;
	}
	@Override
	public String toString() {
		return "ShopkeeperProduct [shopkeeperproductid=" + shopkeeperproductid + ", shopkeeperproductname="
				+ shopkeeperproductname + ", shopkeeperproductquantity=" + shopkeeperproductquantity
				+ ", shopkeeperproductprice=" + shopkeeperproductprice + "]";
	}
	
	

}
