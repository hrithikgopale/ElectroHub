package com.edu.service;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;

import com.edu.dao.Admin;
import com.edu.error.GlobalException;
import com.edu.repository.AdminRepository;
@Service
public class AdminServiceImpl implements AdminService{
       @Autowired
	private AdminRepository adminRepositoy;
	@Override
	public Admin saveAdmin(@Valid Admin admin) throws GlobalException {
		if (adminRepositoy.existsByAdminname(admin.getAdminname())) {
			throw new GlobalException("The admin name already exists");
			
        } 
        	return adminRepositoy.save(admin);
        	
	}
	@Override
	public String deleteAdminByAdminname(String adminname) throws GlobalException {
		// TODO Auto-generated method stub
		int i=adminRepositoy.delete(adminname);
		if(i>0) {
			return "Record is deleted";
		}
		
		throw new GlobalException("Record with name "+adminname+" not exists");
		
		
	}
	

	@Override
	public List<Admin> getAllAdmin() {
		// TODO Auto-generated method stub
		 return adminRepositoy.findAll();
	}
	
	@Override
	public boolean loginAdmin(String adminname, String adminpassword) {
		Admin admin=adminRepositoy.findByAdminname(adminname);
		if(admin !=null && admin.getAdminpassword().equals(adminpassword)) {
			return true;
	}
			return false;
	}

	
}