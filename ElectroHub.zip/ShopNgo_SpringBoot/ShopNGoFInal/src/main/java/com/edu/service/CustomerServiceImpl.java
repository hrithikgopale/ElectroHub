package com.edu.service;

import java.sql.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.dao.Customer;
import com.edu.error.GlobalException;
import com.edu.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService{
	@Autowired
	private CustomerRepository customerrepository;

	@Override
	public Customer registerCustomer(@Valid Customer customer) throws GlobalException {
		
		if(customerrepository.existsByCustomeremailid(customer.getCustomeremailid())) {
			throw new GlobalException("The Email is already registered");
		}
		
		if(customerrepository.existsByCustomerphoneno(customer.getCustomerphoneno())) {
			throw new GlobalException("The phone number is already registered");
		}
		
		return customerrepository.save(customer);
	}

	@Override
	public boolean loginCustomer(String customerphoneno, String customerpassword) {

		Customer customer = customerrepository.findByCustomerphoneno(customerphoneno);
			if(customer !=null && customer.getCustomerpassword().equals(customerpassword)) {
			return true;
	}
			return false;

}

	@Override
	public List<Customer> getAllCustomer() {
		// TODO Auto-generated method stub
		return customerrepository.findAll();
	}

	@Override
	public Customer getCustomerByPhoneno(String cname) {
		return customerrepository.getCustomerByPhoneno(cname);
	}

	@Override
	public void deleteCustomerByCustomerPhoneno(String cpno) {
		customerrepository.deleteCustomerByCustomerPhoneno(cpno);
	}

	@Override
	public String updateCustomerByCustomerPhoneno(String cpno, String customerfirstname) {
	
		customerrepository.updateCustomerByCustomerPhoneno(cpno,customerfirstname);
		
		return "The customer is updated";
	
	}

	@Override
	public void updateCustomerLastname(String cpno, String customerlastname) {
		
		customerrepository.updateCustomerLastname(cpno,customerlastname);
		
	}

	@Override
	public void updateCustomerPassword(String cpno, String customerpassword) {
	
		customerrepository.updateCustomerPassword(cpno,customerpassword);
	}

	@Override
	public void updateCustomerEmailid (@Valid String cpno, String customeremailid) throws GlobalException {
		Customer customer=new Customer();
		if(customerrepository.existsByCustomeremailid(customer.getCustomeremailid())) {
			throw new GlobalException("The Email is already registered");
		}
		
		customerrepository.updateCustomerEmailid(cpno,customeremailid);
	}

	@Override
	public void updateCustomerdob(@Valid String cpno, Date customerdob) {
		
		customerrepository.updateCustomerdob(cpno,customerdob);
	}

	@Override
	public Customer updateCustomerByCustomerid(@Valid Integer customerid, Customer customer) throws GlobalException {
		
		if(customerrepository.existsByCustomeremailid(customer.getCustomeremailid())) {
			throw new GlobalException("The Email is already registered");
		}
		
		if(customerrepository.existsByCustomerphoneno(customer.getCustomerphoneno())) {
			throw new GlobalException("The phone number is already registered");
		}
		
		Customer updatecust=customerrepository.findById(customerid).get();
		updatecust.setCustomerfirstname(customer.getCustomerfirstname());
		updatecust.setCustomerlastname(customer.getCustomerlastname());
		updatecust.setCustomerpassword(customer.getCustomerpassword());
		updatecust.setCustomeremailid(customer.getCustomeremailid());
		updatecust.setCustomerphoneno(customer.getCustomerphoneno());
		updatecust.setCustomerdob(customer.getCustomerdob());
		return customerrepository.save(updatecust);
	}

	@Override
	public List<Customer> deleteByCustomerid(Integer customerid) {
		
		customerrepository.deleteByCustomerid(customerid);
		return customerrepository.findAll();
	}
	

	

	
}

	
