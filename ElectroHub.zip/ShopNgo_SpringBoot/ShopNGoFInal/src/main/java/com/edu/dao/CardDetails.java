package com.edu.dao;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

@Entity
public class CardDetails {


	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

     @NotBlank(message = "Card number is required")
	 @Size(min = 16, max = 16, message = "Card number must be 16 digits")
	 @Pattern(regexp = "^[0-9]+$", message = "Card number must contain only digits")
    private String cardNumber;
     @NotBlank(message = "Cardholder name is required")
    private String cardHolderName;
     @NotBlank(message = "Expiry date is required")
     @Pattern(regexp = "^(0[1-9]|1[0-2])\\/([0-9]{2})$", message = "Expiry date must be in MM/YY format")
    private String expiryDate;
     @NotBlank(message = "CVV is required")
     @Size(min = 3, max = 4, message = "CVV must be 3 or 4 digits")
     @Pattern(regexp = "^[0-9]+$", message = "CVV must contain only digits")
    private String cvv;
    
    
    
	public CardDetails() {
		super();
		// TODO Auto-generated constructor stub
	}



	public CardDetails(Integer id, String cardNumber, String cardHolderName, String expiryDate, String cvv) {
		super();
		this.id = id;
		this.cardNumber = cardNumber;
		this.cardHolderName = cardHolderName;
		this.expiryDate = expiryDate;
		this.cvv = cvv;
	}



	public Integer getId() {
		return id;
	}



	public void setId(Integer id) {
		this.id = id;
	}



	public String getCardNumber() {
		return cardNumber;
	}



	public void setCardNumber(String cardNumber) {
		this.cardNumber = cardNumber;
	}



	public String getCardHolderName() {
		return cardHolderName;
	}



	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName = cardHolderName;
	}



	public String getExpiryDate() {
		return expiryDate;
	}



	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}



	public String getCvv() {
		return cvv;
	}



	public void setCvv(String cvv) {
		this.cvv = cvv;
	}



	@Override
	public String toString() {
		return "CardDetails [id=" + id + ", cardNumber=" + cardNumber + ", cardHolderName=" + cardHolderName
				+ ", expiryDate=" + expiryDate + ", cvv=" + cvv + "]";
	}
    
}