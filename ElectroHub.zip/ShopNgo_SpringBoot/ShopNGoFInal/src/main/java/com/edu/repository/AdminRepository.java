package com.edu.repository;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.edu.dao.Admin;

public interface AdminRepository extends JpaRepository<Admin, Integer> {
	
	@Query(value="select adminname from admin ",nativeQuery = true)
	public List<String>saveAllName();

	

	public boolean existsByAdminname(String adminname);

	@Transactional
	@Modifying
@Query(value = "delete from admin where adminname=?1 ",nativeQuery = true)
	public int delete(String adminname);


@Query(value = "select * from admin where adminname=?1",nativeQuery = true)
public Admin findByAdminname(String adminname);

	

}
