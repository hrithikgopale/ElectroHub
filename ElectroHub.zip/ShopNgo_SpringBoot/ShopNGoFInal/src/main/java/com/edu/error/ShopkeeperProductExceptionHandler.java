package com.edu.error;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;



@RestControllerAdvice
public class ShopkeeperProductExceptionHandler {

	
	
	 @ExceptionHandler(GlobalException.class)
	    public ResponseEntity<String> handleAdminNameAlreadyExistsException(GlobalException ex) {
	        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(ex.getMessage());
	    }
}

